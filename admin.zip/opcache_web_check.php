<?php
header('Content-Type:text/plain; charset=utf-8');
echo 'SAPI='.php_sapi_name()."\n";
echo 'opcache.enable='.ini_get('opcache.enable')."\n";
echo 'opcache.validate_timestamps='.ini_get('opcache.validate_timestamps')."\n";
echo 'opcache.revalidate_freq='.ini_get('opcache.revalidate_freq')."\n";
echo 'opcache.file_update_protection='.ini_get('opcache.file_update_protection')."\n";
echo 'loaded_ini='.php_ini_loaded_file()."\n";
?>
