<?php
/*  chat-GPT ERP sign: sysempire@gmail.com  */

ini_set('display_errors', 1);
error_reporting(E_ALL);

include_once __DIR__.'/common.php';
require_once __DIR__.'/vendor/autoload.php';

use chillerlan\QRCode\QRCode;
use chillerlan\QRCode\QROptions;

$text = isset($_GET['text']) ? trim($_GET['text']) : '';

if($text === ''){
    header('Content-Type: text/plain; charset=utf-8');
    exit('empty');
}

$options = new QROptions([
    'outputType' => QRCode::OUTPUT_MARKUP_SVG,
    'eccLevel'   => QRCode::ECC_M,
    'scale'      => 5,
]);

header('Content-Type: image/svg+xml; charset=utf-8');
echo (new QRCode($options))->render($text);
exit;